<?php
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_email'])) {
    $records = $conn->prepare('SELECT email, password FROM Table_admin WHERE email = :email');
    $records->bindParam(':email', $_SESSION['user_email']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Sistema Examén</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>
    <?php require 'partials/header.php' ?>

    <?php if(!empty($user)): ?>
      <br> Bienvenido <?= $user['email']; ?>
      <br>Iniciando sesion
      <a href="logout.php">
        Logout
      </a>
    <?php else: ?>
      <h1>Por favor Ingresa o Registrate</h1>

      <a href="login.php">Ingresar sesión</a> or
      <a href="signup.php">Cerrar sesión</a>
    <?php endif; ?>
  </body>
</html>
