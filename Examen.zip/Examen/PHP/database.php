<?php

$server = 'localhost:3307';
$username = 'root';
$password = '';
$database = 'Examen';

try {
  $conn = new PDO("sqlsrv_connect:host=$server;dbname=$database;", $email, $password);
} catch (PDOException $e) {
  die('Connection Failed: ' . $e->getMessage());
}

?>
